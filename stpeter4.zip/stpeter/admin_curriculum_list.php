<?php
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>HMIS</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('admin_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <?php
                      // Check if the success message is set in the session and display it
                      if (isset($_SESSION['success'])) {
                          echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                          unset($_SESSION['success']); // Clear the success message from the session
                      }
                      else if (isset($_SESSION['danger'])) {
                          echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                          unset($_SESSION['danger']); // Clear the success message from the session
                      }

                      ?>
            <div class="container-fluid fontStyle" >
                
                <div class="row">
                    
              </div>


               <div class="tab-content">
                    <div id="admin" class="container tab-pane active"><br>
                      <h3>Manage Casualties</h3>
                      <br>
                       <?php 
                          $res = mysqli_query($conn, "SELECT * FROM tbl_accident order by ID desc");
                          if($res){
                            $rowcount = mysqli_num_rows($res);
                          }
                          
                          ?>    
                          
                          <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addAdmin">Add New Data</button>            
                          <br><br>
                          <table class='table table-bordered table-striped'>
                            <tr style="background: #d9d9d9 !important; text-align: center;">
                              <th>ID</th>
                              <th>Area</th>
                              <th>Time and Date</th>
                              <th>Description</th>
                              <th>Remarks</th>
                              <th>Edit</th> 
                              <th>Delete</th>                                                               
                            </tr>
                          <?php while($row = mysqli_fetch_array($res)){ ?>
                            <tr>
                              <td><?php echo $row["id"]; ?> </td>
                              <td><?php echo $row["area"]; ?></td>           
                              <td><?php echo $row["time_date"]; ?></td>
                              <td><?php echo $row["description"]; ?></td>   
                              <td><?php echo $row["remarks"]; ?></td>
                            <td><?php echo '<button class="btn btn-warning editBtnAdmin" data-toggle="modal" data-target="#editBtnAdmin">Edit</button>' ?> </td> 
                              <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
                            </tr>
                            <?php
                            }
                            ?>
                          </table>


                    </div>
                

 <div id="addAdmin" class="modal fade fontStyle" role="dialog" style="zoom: 90%;">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <form action="" method="post">  
              <div class="modal-header">
                <h4 class="modal-title">Add New Data</h4>
              </div>     
          <div class="modal-body">

              <div class="form-group">
                <label for="usr">Area:</label>
                <input type="text" name="area" class="form-control">
              </div>

              <div class="form-group">
                <label for="usr">Time and Date:</label>
                <input type="date" name="time_date" class="form-control" required >
              </div>
              <div class="form-group">
                <label for="usr">Description:</label>
                <input type="text" name="description" class="form-control" required>
              </div>  

              <div class="form-group">
                <label for="usr">Remarks:</label>
                <input type="text" name="remarks" class="form-control" required >
              </div>


            </div>
            <div class="modal-footer">
              <button type="submit" name="addData" class="btn btn-primary">Add Data</button>
              <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
            </div>
          </form>
    </div>
  </div>
</div>   


<!-- Update Modal -->
<div id="editBtnAdmin" class="modal fade" role="">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <form action="" method="post">
      <div class="modal-header">
        <h4 class="modal-title">Update Admin</h4>
      </div>     
      <div class="modal-body">      
        <input id="update_admin_id" name="update_admin_id" type="hidden">

        
              <div class="form-group">
                <label for="usr">Area:</label>
                <input type="text" name="area" id="area" class="form-control">
              </div>

              <div class="form-group">
                <label for="usr">Time and Date:</label>
                <input type="date" name="time_date" id="time_date" class="form-control" required >
              </div>
              <div class="form-group">
                <label for="usr">Description:</label>
                <input type="text" name="description" id="description" class="form-control" required>
              </div>  

              <div class="form-group">
                <label for="usr">Remarks:</label>
                <input type="text" name="remarks" id="remarks" class="form-control" required >
              </div>




        </div>

        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->




<!-- Delete Modal -->
<div id="deleteAdmin" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete Data</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_id" name="delete_id" type="hidden">
          <p>Are you sure you want to delete this data?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>
<!-- ADD QUERY [ADD NEW USER] -->  
<?php 
  if(isset($_POST["addData"]))
     {

               $area = mysqli_real_escape_string($conn, $_POST["area"]);
               $time_date = mysqli_real_escape_string($conn, $_POST["time_date"]);
               $description = mysqli_real_escape_string($conn, $_POST["description"]);
               $remarks = mysqli_real_escape_string($conn, $_POST["remarks"]);


        $query_show = mysqli_query($conn, "SELECT * FROM tbl_accident");
        
   
              //else, i-eexecute nya yung insert query
              $query_insert = mysqli_query($conn, "INSERT INTO tbl_accident 
                  VALUES('', '$area', 
                  '$time_date', '$description',
                  '$remarks'
                )");
                if($query_insert)
                {            
                  $_SESSION['success'] = 'Data Inserted'; // Set the success message in the session
                   echo '<script> window.location="admin_accident.php";</script>';                        
                }
            
            
          
      }

     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($conn, "DELETE FROM tbl_accident WHERE id='$id'");
        if($query) {
          $_SESSION['success'] = 'Data Deleted'; // Set the success message in the session
          echo '<script> window.location="admin_accident.php";</script>';              
         
        }
     }
?>  




<!-- UPDATE QUERY [EDIT ADMIN USER] -->                 
<?php 
     if(isset($_POST['updateData'])){    
        $id = $_POST['update_admin_id'];

        $area = mysqli_real_escape_string($conn, $_POST["area"]);
        $time_date = mysqli_real_escape_string($conn, $_POST["time_date"]);
        $description = mysqli_real_escape_string($conn, $_POST["description"]);
        $remarks = mysqli_real_escape_string($conn, $_POST["remarks"]);
    


        $query = mysqli_query($conn, "UPDATE tbl_accident 
          SET 
          area='$area', 
          time_date='$time_date', 
          description='$description',  
          remarks='$remarks'
          WHERE id='$id'");
        if($query) {
              $_SESSION['success'] = 'Successfully Updated'; // Set the success message in the session
               echo '<script> window.location="admin_accident.php";</script>';              
            ;
        }
     }
?>






<!-- End of Delete Modal -->

            </div>
        </div>
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>



<script>
    $(document).ready(function(){
        $('.deleteAdmin').on('click', function(){
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });




 $(document).ready(function(){
        $('.deleteUser').on('click', function(){
            
         //   $('#deleteUser').modal('show');

       //     $('#deleteUser').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_ids').val(data[0]);          
        });
    });



$(document).ready(function(){
    $('.editBtnAdmin').on('click', function(){      
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();
            $('#update_admin_id').val(data[0]);
            $('#area').val(data[1]);
            $('#time_date').val(data[2]);
            $('#description').val(data[3]);   
            $('#remarks').val(data[4]);




    });
 });




$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});



 var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };


$('input[type="file"]'). change(function(e){
    fileName = e. target. files[0]. name;
    $('#imgLabel').text(fileName);
    $('#imgPreview').attr('src','images/'+fileName);
});



function searchBar() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("searchUser");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableUser");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}




var $td = $('table td').eq(4),
    text = $td.text().replace(/\*/g, '%');

$td.text(text);


</script>


<script>
   // Get all the alerts with the "auto-close" class
  var alerts = document.querySelectorAll('.alert');

  // Loop through the alerts and set a timeout function to remove them after 4 seconds
  alerts.forEach(function(alert) {
    setTimeout(function() {
      alert.remove();
    }, 4000);
  });
</script>










