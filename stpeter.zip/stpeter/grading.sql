-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2023 at 10:44 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grading`
--

-- --------------------------------------------------------

--
-- Table structure for table `parentorguardian`
--

CREATE TABLE `parentorguardian` (
  `ParentID` int(11) NOT NULL,
  `FatherFullname` varchar(255) DEFAULT NULL,
  `FatherOccupation` varchar(255) DEFAULT NULL,
  `FathersContactNumber` varchar(20) DEFAULT NULL,
  `MotherFullname` varchar(255) DEFAULT NULL,
  `MotherOccupation` varchar(255) DEFAULT NULL,
  `MotherContactNumber` varchar(20) DEFAULT NULL,
  `GuardianFullname` varchar(255) DEFAULT NULL,
  `RelationshipToStudent` varchar(255) DEFAULT NULL,
  `ContactNum` varchar(20) DEFAULT NULL,
  `StudentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parentorguardian`
--

INSERT INTO `parentorguardian` (`ParentID`, `FatherFullname`, `FatherOccupation`, `FathersContactNumber`, `MotherFullname`, `MotherOccupation`, `MotherContactNumber`, `GuardianFullname`, `RelationshipToStudent`, `ContactNum`, `StudentID`) VALUES
(1, 'b421b41242b', 'b421b41242b', 'b421b41242b', 'b421b41242b', 'b421b41242b', 'b421b41242b', 'b421b41242b', 'b421b41242b', '', 0),
(2, 'g421g412', 'g421g412', 'g421g412', 'g421g412', 'g421g412', 'g421g412', 'g421g412', '', '', 0),
(3, '1111', '11111111', '1111', '1111', '1111', '1111', '1111', '', '', 1111),
(4, '12313', '12313', '12313', '12313', '12313', '12313', '12313', '', '', 12313),
(6, 'h4', 'h4', 'h44', 'h4bb', 'h4', 'h4', 'h4', 'h4', 'h4', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(255) DEFAULT NULL,
  `Lname` varchar(255) DEFAULT NULL,
  `MName` varchar(255) DEFAULT NULL,
  `Suffix` varchar(10) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `ParentsOrGuardian` varchar(255) DEFAULT NULL,
  `ContactNum` varchar(20) DEFAULT NULL,
  `EmailAddress` varchar(255) DEFAULT NULL,
  `TypeOfStudent` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `Fname`, `Lname`, `MName`, `Suffix`, `Gender`, `Age`, `DateOfBirth`, `Address`, `ParentsOrGuardian`, `ContactNum`, `EmailAddress`, `TypeOfStudent`) VALUES
(1, 'h4124h21h4', 'h4124h21h4', 'h4124h21h4', 'h4124h21h4', 'h4124h21h4', 4124214, '2023-10-18', 'h4124h21h4', 'h4124h21h4', '4124214', 'h4124h21h4@gma', ''),
(4, '', '', '', '', '', 0, '0000-00-00', '', '', '12313', '', ''),
(5, '$Fname', '$Lname', '$MName', '$Suffix', '$Gender', 0, '0000-00-00', '$Address', '$ParentsOrGuardian', '$ContactNum', '$EmailAddress', ''),
(6, '123', '123', '123', '123', '123', 123, '2023-10-19', '123', '123', '123', '424242@gmail.com', ''),
(8, '42114124', '42114124', '42114124', '42114124', '42114124', 42114124, '2023-10-10', '42114124', '42114124', '42114124', '42114124@4h21h414', 'New Student'),
(9, 'John', 'Cruz', 'Dela', 'Jr', 'Male', 11, '2012-06-12', '123 victoria st. laguna', 'Juan dela cruz', '09123456789', 'johncruz@gmail.com', 'Transferee');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `ID` int(11) NOT NULL,
  `subject_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`ID`, `subject_name`) VALUES
(1, 'Math'),
(3, 'English'),
(4, 'ESP');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '$2y$10$lvBXIolFQqmeHJzhjo06BOsa5UiUtE42w78ziu9tdhghlR/Ynswzu'),
(2, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(3, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(4, 'lastica', 'mark', 'aldrin', 'users', 'user'),
(5, 'newonly', 'newonly', 'newonly', 'newonly', '$2y$10$wn3pCl3.VPv7l8MKsx5gxe/EyKIdNYQxGciZiP4ezyLGpzTQG5yUa'),
(6, 'pogi', 'miguelfranz', '321e', '321e', '$2y$10$hALq9R0y0kCairlanN3xv.cNpkiyBWaY.9CEGzzY7yBz2ii5sIBKa'),
(7, 'b1322', 'b132', 'b132', 'b132', '$2y$10$XBB5l.kcy/yrjH1Y/jWr1.LS8hJP.4WLtbn/hKmxS2iJWAkmdfDH.'),
(8, 'test', 'test', 'test', 'test', '$2y$10$oqjjjs6hX0A/xHhsrc141O/t.N1UPB9dGat2f2sCRZ2LCnpK71kUK');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_parents_credentials`
--

CREATE TABLE `tbl_parents_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_parents_credentials`
--

INSERT INTO `tbl_parents_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `section`) VALUES
(1, 'user', 'user', 'user', 'user', '$2y$10$MOOOrssDON3cK3b8a6Ehxeu.sQwBhjs86g/H0G2.T9lV6q2ooQuxO', 'user'),
(2, 'awa', 'awa', 'awa', 'awa', 'awa', 'awa'),
(3, 'pogi', 'miguelfranz', '321', '1231', '1231', 'NULL'),
(4, 'tests', 'tests', '123', '123', '$2y$10$/54ZhDq7pcaQv6diqOBRUujk/.8mOqLB5btN5ZL6ErmGNAZoMd8JC', 'NULL');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `section`) VALUES
(1, 'user', 'user', 'user', 'user', '$2y$10$MOOOrssDON3cK3b8a6Ehxeu.sQwBhjs86g/H0G2.T9lV6q2ooQuxO', 'user'),
(2, 'awa', 'awa', 'awa', 'awa', 'awa', 'awa'),
(3, 'pogi', 'miguelfranz', '321', '1231', '1231', 'NULL'),
(4, 'tests', 'tests', '123', '123', '$2y$10$/54ZhDq7pcaQv6diqOBRUujk/.8mOqLB5btN5ZL6ErmGNAZoMd8JC', 'NULL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `parentorguardian`
--
ALTER TABLE `parentorguardian`
  ADD PRIMARY KEY (`ParentID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_parents_credentials`
--
ALTER TABLE `tbl_parents_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `parentorguardian`
--
ALTER TABLE `parentorguardian`
  MODIFY `ParentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_parents_credentials`
--
ALTER TABLE `tbl_parents_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
