<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<?php
include('connection.php');

session_start();  


// ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     <title>Enrollment System</title>
     <link rel="stylesheet" type="text/css" href="style.css">


</head>

<body>

    <!-- Navigation -->
	<?php 
		include('header_index.php');
	?>

    <!-- Page Content -->
    <div class="container-fluid fontStyle">
        <div class="content-wrapper">
		<center>
            <?php
                      // Check if the success message is set in the session and display it
                      if (isset($_SESSION['success'])) {
                          echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                          unset($_SESSION['success']); // Clear the success message from the session
                      }
                      else if (isset($_SESSION['danger'])) {
                          echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                          unset($_SESSION['danger']); // Clear the success message from the session
                      }

                      ?>
            <div class="row" style="max-width: 1500px;">
                
                <div class="col-md-6 col-lg-6 text-left">
                    <p>
                    <h1 class="font arrange-content left-pad" style="color: #7975fe;"><span style="color: black;">Welcome to</span> <br/> <b>Registration</b></h1>
                    </p>
                    <p class="description left-pad"> A school registration form helps students register they are interested in.</p>
                    <div class="left-pad">
						
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 text-left hidden-xs hidden-sm laptop arrange-content">
                    <form action="" method="post">  
                          <div class="form-group">
                            <label for="usr">First Name:</label>
                            <input type="text" name="Fname" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="usr">Last Name:</label>
                            <input type="text" name="Lname" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="usr">Middle Name:</label>
                            <input type="text" name="MName" class="form-control">
                          </div>
                          <div class="form-group">
                            <label for="usr">Suffix:</label>
                            <input type="text" name="Suffix" class="form-control" required >
                          </div>
                          <div class="form-group">
                            <label for="usr">Gender:</label>
                            <input type="text" name="Gender" class="form-control" required>
                          </div>    
                          <div class="form-group">
                            <label for="usr">Age:</label>
                            <input type="number" name="Age" class="form-control" required >
                          </div>
                          <div class="form-group">
                            <label for="usr">Date Of Birth:</label>
                            <input type="date" name="DateOfBirth" class="form-control" required>
                          </div>    
                          <div class="form-group">
                            <label for="usr">Address:</label>
                            <input type="text" name="Address" class="form-control" required >
                          </div>
                          <div class="form-group">
                            <label for="usr">Parents Or Guardian:</label>
                            <input type="text" name="ParentsOrGuardian" class="form-control" required>
                          </div>    
                          <div class="form-group">
                            <label for="usr">Contact Number:</label>
                            <input type="number" name="ContactNum" class="form-control" required >
                          </div>
                          <div class="form-group">
                            <label for="usr">Email Address:</label>
                            <input type="email" name="EmailAddress" class="form-control" required>
                          </div>   
                           <div class="form-group">
                            <label for="usr">Type of Student:</label>
                              <select class="form-control" name="TypeOfStudent">
                                  <option value="Regular">Regular</option>
                                  <option value="Transferee">Transferee</option>
                                  <option value="New Student">New Student</option>
                              </select>
                          </div>   



                          <div class="form-group">
                            <button type="submit" name="addData" class="btn btn-primary">Register</button>  
                          </div>
                    </form>
                </div>

                <?php 
                  if(isset($_POST["addData"]))
                     {
                        $Fname = mysqli_real_escape_string($conn, $_POST["Fname"]);
                        $Lname = mysqli_real_escape_string($conn, $_POST["Lname"]);
                        $MName = mysqli_real_escape_string($conn, $_POST["MName"]);
                        $Suffix = mysqli_real_escape_string($conn, $_POST["Suffix"]);  
                        $Gender = mysqli_real_escape_string($conn, $_POST["Gender"]);
                        $Age = mysqli_real_escape_string($conn, $_POST["Age"]);
                        $DateOfBirth = mysqli_real_escape_string($conn, $_POST["DateOfBirth"]);
                        $Address = mysqli_real_escape_string($conn, $_POST["Address"]);
                        $ParentsOrGuardian = mysqli_real_escape_string($conn, $_POST["ParentsOrGuardian"]);  
                        $ContactNum = mysqli_real_escape_string($conn, $_POST["ContactNum"]);
                        $EmailAddress = mysqli_real_escape_string($conn, $_POST["EmailAddress"]);
                        $TypeOfStudent = mysqli_real_escape_string($conn, $_POST["TypeOfStudent"]);

                        $query_show = mysqli_query($conn, "SELECT * FROM student");
                        
                        $query = mysqli_query($conn, "SELECT * FROM student WHERE Fname='$Fname' AND Lname='$Lname'");
                         if(mysqli_num_rows($query) > 0) 
                         {
                              $_SESSION['danger'] = 'The student name already exists'; // Set the success message in the session
                              echo '<script> window.location="registration.php";</script>';       
                         }
                         else 
                         {
                              //else, i-eexecute nya yung insert query
                              $query_insert = mysqli_query($conn, "INSERT INTO student 
                                  VALUES('', '$Fname', '$Lname', '$MName', 
                                  '$Suffix', '$Gender', '$Age', '$DateOfBirth', 
                                  '$Address', '$ParentsOrGuardian', 
                                  '$ContactNum', '$EmailAddress', '$TypeOfStudent')");
                                if($query_insert)
                                {            
                                  $_SESSION['success'] = 'Registration Completed!'; // Set the success message in the session
                                   echo '<script> window.location="registration.php";</script>';                        
                                }
                            
                            
                          }
                      }

                     if(isset($_POST['deleteData'])){    
                        $id = $_POST['delete_id'];
                        $query = mysqli_query($conn, "DELETE FROM student WHERE id='$id'");
                        if($query) {
                          $_SESSION['success'] = 'Data Deleted'; // Set the success message in the session
                          echo '<script> window.location="registration.php";</script>';              
                         
                        }
                     }
                ?>  







                    
                </div>
            </div>
			</center>
        </div>
    </div>

</body>

</html>
