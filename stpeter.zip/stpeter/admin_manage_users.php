<?php
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Enrollment System</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('admin_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <?php
                      // Check if the success message is set in the session and display it
                      if (isset($_SESSION['success'])) {
                          echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                          unset($_SESSION['success']); // Clear the success message from the session
                      }
                      else if (isset($_SESSION['danger'])) {
                          echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                          unset($_SESSION['danger']); // Clear the success message from the session
                      }

                      ?>
            <div class="container-fluid fontStyle" >
                
                <div class="row">
                    <div class="">
                    <ul class="nav nav-pills justify-content-center mt-3" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" data-toggle="pill" href="#admin">Parents</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" data-toggle="pill" href="#user">Students</a>
                        </li>
                        
                      </ul>
                    </div>
              </div>


               <div class="tab-content">
                    <div id="admin" class=" tab-pane active"><br>
                      <h3>Manage Admin Credentials</h3>
                      <br>
                       <?php 
                          $res = mysqli_query($conn, "SELECT * FROM parentorguardian order by PARENTID desc");
                          if($res){
                            $rowcount = mysqli_num_rows($res);
                          }
                          
                          ?>    
                          
                          <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addAdmin">Add New Admin</button>            
                          <br><br>
                          <table class='table table-bordered table-striped table-responsive'>
                            <tr style="background: #d9d9d9 !important; text-align: center;">
                              <th>ID</th>
                              <th>Father Full Name</th>
                              <th>Father Occupation</th>
                              <th>Fathers Contact Number</th>
                              <th>Mother Full name</th>
                              <th>Mother Occupation</th>
                              <th>Mother Contact Number</th>
                              <th>Guardian Full Name</th>
                              <th>Relationship To Student</th>
                              <th>Contact Number</th>
                              <th>Edit</th> 
                              <th>Delete</th>                                                               
                            </tr>
                          <?php while($row = mysqli_fetch_array($res)){ ?>
                            <tr>
                              <td><?php echo $row["ParentID"]; ?> </td>
                              <td><?php echo $row["FatherFullname"]; ?></td>
                              <td><?php echo $row["FatherOccupation"]; ?></td>
                              <td><?php echo $row["FathersContactNumber"]; ?></td>           
                              <td><?php echo $row["MotherFullname"]; ?></td>
                              <td><?php echo $row["MotherOccupation"]; ?></td> 
                              <td><?php echo $row["MotherContactNumber"]; ?></td>
                              <td><?php echo $row["GuardianFullname"]; ?></td>       
                              <td><?php echo $row["RelationshipToStudent"]; ?></td>
                              <td><?php echo $row["ContactNum"]; ?></td> 

                            <td><?php echo '<button class="btn btn-warning editBtnAdmin" data-toggle="modal" data-target="#editBtnAdmin">Edit</button>' ?> </td> 
                            <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
                            </tr>
                            <?php
                            }
                            ?>
                          </table>


                    </div>
                   <div id="user" class=" tab-pane fade">  
                          <h2>Manage User Credentials</h2>
                          <br>
                          <?php 
                          $res = mysqli_query($conn, "SELECT * FROM student order by ID desc");
                          if($res){
                            $rowcount = mysqli_num_rows($res);
                          }
                          
                          ?>  

                          <input type="text" id="searchUser" onkeyup="searchBar()" class="form-control" placeholder="Search by last name">
                          <br>  
                          
                          <button class="btn btn-primary" style="float: left;" data-toggle="modal" data-target="#addBtnUser">Add New Student</button>            
                          <br><br>
                              
                        <table class='table table-bordered table-striped table-responsive' id="tableUser">
                            <tr style="background: #d9d9d9 !important; text-align: center;">
                              <th>ID</th>
                              <th>First Name</th>
                              <th>Last Name</th>
                              <th>Middle Name</th>
                              <th>Suffix</th>
                              <th>Gender</th> 
                              <th>Age</th>
                              <th>Date of Birth</th>
                              <th>Address</th>
                              <th>Parents or Guardian</th>
                              <th>Contact Number</th> 
                              <th>Email Address</th> 
                              <th>Type of Student</th> 
                              <th>Edit</th> 
                              <th>Delete</th>                                                               
                            </tr>
                          <?php while($row = mysqli_fetch_array($res)){ ?>
                            <tr>
                              <td><?php echo $row["ID"]; ?> </td>
                              <td><?php echo $row["Fname"]; ?></td>
                              <td><?php echo $row["Lname"]; ?></td>
                              <td><?php echo $row["MName"]; ?></td>           
                              <td><?php echo $row["Suffix"]; ?></td>
                              <td><?php echo $row["Gender"]; ?></td> 
                              <td><?php echo $row["Age"]; ?></td>
                              <td><?php echo $row["DateOfBirth"]; ?></td>
                              <td><?php echo $row["Address"]; ?></td>           
                              <td><?php echo $row["ParentsOrGuardian"]; ?></td>
                              <td><?php echo $row["ContactNum"]; ?></td> 
                              <td><?php echo $row["EmailAddress"]; ?></td> 
                              <td><?php echo $row["TypeOfStudent"]; ?></td> 



                             <td><?php echo '<button class="btn btn-warning editBtnUser" data-toggle="modal" data-target="#editBtnUser">Edit</button>' ?> </td> 
                              <td><?php echo '<button class="btn btn-danger deleteUser" data-toggle="modal" data-target="#deleteUser">Delete</button>' ?> </td>
                            </tr> 
                             <?php
                            }
                            ?>
                          </table>

                      </div>                 
                </div>

 <div id="addAdmin" class="modal fade fontStyle" role="dialog" style="zoom: 90%;">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <form action="" method="post">  
              <div class="modal-header">
                <h4 class="modal-title">Add New Admin</h4>
              </div>     
          <div class="modal-body">
              
              <div class="form-group">
                <label for="usr">Father Full Name:</label>
                <input type="text" name="FatherFullname" class="form-control" required>
              </div>

              <div class="form-group">
                <label for="usr">Father Occupation:</label>
                <input type="text" name="FatherOccupation" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="usr">Fathers Contact Number:</label>
                <input type="text" name="FathersContactNumber" class="form-control">
              </div>

              <div class="form-group">
                <label for="usr">Mother Full name:</label>
                <input type="text" name="MotherFullname" class="form-control" required >
              </div>

              <div class="form-group">
                <label for="usr">Mother Occupation:</label>
                <input type="text" name="MotherOccupation" class="form-control" required >
              </div>

              <div class="form-group">
                <label for="usr">Mother Contact Number:</label>
                <input type="text" name="MotherContactNumber" class="form-control" required >
              </div>

              <div class="form-group">
                <label for="usr">Guardian Full name:</label>
                <input type="text" name="GuardianFullname" class="form-control" required >
              </div>

              <div class="form-group">
                <label for="usr">Relationship To Student:</label>
                <input type="text" name="RelationshipToStudent" class="form-control" required >
              </div>

               <div class="form-group">
                <label for="usr">Contact Number:</label>
                <input type="text" name="ContactNum" class="form-control" required >
              </div>

            

            </div>
            <div class="modal-footer">
              <button type="submit" name="addData" class="btn btn-primary">Add Admin</button>
              <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
            </div>
          </form>
    </div>
  </div>
</div>   


<!-- Update Modal -->
<div id="editBtnAdmin" class="modal fade" role="">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <form action="" method="post">
      <div class="modal-header">
        <h4 class="modal-title">Update Admin</h4>
      </div>     
      <div class="modal-body">      
        <input id="update_admin_id" name="update_admin_id" type="hidden">
            
          <div class="form-group">
                       <label for="usr">Father Full Name:</label>
                       <input type="text" name="FatherFullname" id="FatherFullname" class="form-control" required>
                     </div>

                     <div class="form-group">
                       <label for="usr">Father Occupation:</label>
                       <input type="text" name="FatherOccupation" id="FatherOccupation" class="form-control" required>
                     </div>
                     <div class="form-group">
                       <label for="usr">Fathers Contact Number:</label>
                       <input type="text" name="FathersContactNumber" id="FathersContactNumber" class="form-control">
                     </div>

                     <div class="form-group">
                       <label for="usr">Mother Full name:</label>
                       <input type="text" name="MotherFullname" id="MotherFullname" class="form-control" required >
                     </div>

                     <div class="form-group">
                       <label for="usr">Mother Occupation:</label>
                       <input type="text" name="MotherOccupation" id="MotherOccupation" class="form-control" required >
                     </div>

                     <div class="form-group">
                       <label for="usr">Mother Contact Number:</label>
                       <input type="text" name="MotherContactNumber" id="MotherContactNumber" class="form-control" required >
                     </div>

                     <div class="form-group">
                       <label for="usr">Guardian Full name:</label>
                       <input type="text" name="GuardianFullname" id="GuardianFullname" class="form-control" required >
                     </div>

                     <div class="form-group">
                       <label for="usr">Relationship To Student:</label>
                       <input type="text" name="RelationshipToStudent" id="RelationshipToStudent" class="form-control" required >
                     </div>

                      <div class="form-group">
                       <label for="usr">Contact Number:</label>
                       <input type="text" name="ContactNum" id="ContactNum" class="form-control" required >
                     </div>


        </div>

        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->




<!-- Delete Modal -->
<div id="deleteAdmin" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_id" name="delete_id" type="hidden">
          <p>Are you sure you want to delete this User?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteData" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>



<!-- ADD QUERY [Add New Student] -->  
<?php 
  if(isset($_POST["addData"]))
     {
        $FatherFullname = mysqli_real_escape_string($conn, $_POST["FatherFullname"]);
        $FatherOccupation = mysqli_real_escape_string($conn, $_POST["FatherOccupation"]);
        $FathersContactNumber = mysqli_real_escape_string($conn, $_POST["FathersContactNumber"]);
        $MotherFullname = mysqli_real_escape_string($conn, $_POST["MotherFullname"]); 
        $MotherOccupation = mysqli_real_escape_string($conn, $_POST["MotherOccupation"]);
        $MotherContactNumber = mysqli_real_escape_string($conn, $_POST["MotherContactNumber"]);
        $GuardianFullname = mysqli_real_escape_string($conn, $_POST["GuardianFullname"]);  
        $RelationshipToStudent = mysqli_real_escape_string($conn, $_POST["RelationshipToStudent"]);
        $ParentsOrGuardian = mysqli_real_escape_string($conn, $_POST["RelationshipToStudent"]);
        $ContactNum = mysqli_real_escape_string($conn, $_POST["ContactNum"]);   

        $query_show = mysqli_query($conn, "SELECT * FROM parentorguardian");
        
        $query = mysqli_query($conn, "SELECT * FROM parentorguardian WHERE FatherFullname='$FatherFullname'");
         if(mysqli_num_rows($query) > 0) 
         {
              $_SESSION['danger'] = 'This parent already exists'; // Set the success message in the session
              echo '<script> window.location="admin_manage_users.php";</script>';       
         }
         else 
         {
       

              $query_insert = mysqli_query($conn, "INSERT INTO parentorguardian 
                  VALUES('', '$FatherFullname', '$FatherOccupation', '$FathersContactNumber',  '$MotherFullname', 
                  '$MotherOccupation', '$MotherContactNumber', '$GuardianFullname', '$RelationshipToStudent', 
               '$ParentsOrGuardian', '$ContactNum')");



                if($query_insert)
                {            
                  $_SESSION['success'] = 'Data Inserted'; // Set the success message in the session
                   echo '<script> window.location="admin_manage_users.php";</script>';                        
                }
            
            
          }
      }

     if(isset($_POST['deleteData'])){    
        $id = $_POST['delete_id'];
        $query = mysqli_query($conn, "DELETE FROM parentorguardian WHERE ParentID=$id");
        if($query) {
          $_SESSION['success'] = 'Data Deleted'; // Set the success message in the session
          echo '<script> window.location="admin_manage_users.php";</script>';              
         
        }
     }
?>  




<!-- UPDATE QUERY [EDIT ADMIN USER] -->                 
<?php 
     if(isset($_POST['updateData'])){    
        $id = $_POST['update_admin_id'];
        $FatherFullname = mysqli_real_escape_string($conn, $_POST["FatherFullname"]);
        $FatherOccupation = mysqli_real_escape_string($conn, $_POST["FatherOccupation"]);
        $FathersContactNumber = mysqli_real_escape_string($conn, $_POST["FathersContactNumber"]);
        $MotherFullname = mysqli_real_escape_string($conn, $_POST["MotherFullname"]); 
        $MotherOccupation = mysqli_real_escape_string($conn, $_POST["MotherOccupation"]);
        $MotherContactNumber = mysqli_real_escape_string($conn, $_POST["MotherContactNumber"]);
        $GuardianFullname = mysqli_real_escape_string($conn, $_POST["GuardianFullname"]);  
        $RelationshipToStudent = mysqli_real_escape_string($conn, $_POST["RelationshipToStudent"]);
        $ContactNum = mysqli_real_escape_string($conn, $_POST["ContactNum"]);   
        
        $query = mysqli_query($conn, "UPDATE parentorguardian 
          SET 
          FatherFullname='$FatherFullname', 
          FatherOccupation='$FatherOccupation', 
          FathersContactNumber='$FathersContactNumber', 
          MotherFullname='$MotherFullname', 
          MotherOccupation='$MotherOccupation',
          MotherContactNumber='$MotherContactNumber', 
          GuardianFullname='$GuardianFullname', 
          RelationshipToStudent='$RelationshipToStudent', 
          ContactNum='$ContactNum'
          WHERE ParentID='$id'");
        if($query) {
              $_SESSION['success'] = 'Successfully Updated'; // Set the success message in the session
               echo '<script> window.location="admin_manage_users.php";</script>';              
            ;
        }
     }
?>

<!-- UPDATE QUERY [EDIT USER USER] -->                 
<?php 
     // if(isset($_POST['updateData'])){    
     //    $id = $_POST['update_user_id'];
     //    $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
     //    $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
     //    $middle_name = mysqli_real_escape_string($conn, $_POST["middle_name"]);
     //    $username = mysqli_real_escape_string($conn, $_POST["username"]);  
     //    $password = mysqli_real_escape_string($conn, $_POST["password"]);
     //    $password = password_hash($password, PASSWORD_BCRYPT);
     //    $query = mysqli_query($conn, "UPDATE tbl_user_credentials 
     //      SET 
     //      last_name='$last_name', 
     //      first_name='$first_name', 
     //      middle_name='$middle_name', 
     //      username='$username', 
     //      password='$password'
     //      WHERE id='$id'");
     //    if($query) {
     //        $_SESSION['success'] = 'Successfully Updated'; // Set the success message in the session
     //         echo '<script> window.location="admin_manage_users.php";</script>';              
     //        ;
     //    }
     // }
?>







<!-- Add Modal -->
<div id="addBtnUser" class="modal fade fontStyle" role="dialog" style="zoom: 90%;">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
    <form action="" method="post" role="form" enctype="multipart/form-data">  
      <div class="modal-header">
        <h4 class="modal-title">Add New Student</h4>
      </div>     

      <div class="modal-body">    
         
          <div class="form-group">
              <label for="usr">First Name:</label>
                <input type="text" name="Fname" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="usr">Last Name:</label>
                <input type="text" name="Lname" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="usr">Middle Name:</label>
                <input type="text" name="MName" class="form-control">
              </div>
              <div class="form-group">
                <label for="usr">Suffix:</label>
                <input type="text" name="Suffix" class="form-control" required >
              </div>
              <div class="form-group">
                <label for="usr">Gender:</label>
                <input type="text" name="Gender" class="form-control" required>
              </div>    
              <div class="form-group">
                <label for="usr">Age:</label>
                <input type="number" name="Age" class="form-control" required >
              </div>
              <div class="form-group">
                <label for="usr">Date Of Birth:</label>
                <input type="date" name="DateOfBirth" class="form-control" required>
              </div>    
              <div class="form-group">
                <label for="usr">Address:</label>
                <input type="text" name="Address" class="form-control" required >
              </div>
              <div class="form-group">
                <label for="usr">Parents Or Guardian:</label>
                <input type="text" name="ParentsOrGuardian" class="form-control" required>
              </div>    
              <div class="form-group">
                <label for="usr">Contact Number:</label>
                <input type="number" name="ContactNum" class="form-control" required >
              </div>
              <div class="form-group">
                <label for="usr">Email Address:</label>
                <input type="email" name="EmailAddress" class="form-control" required>
              </div> 

              <div class="form-group">
                <label for="usr">Type of Student:</label>
                <select class="form-control" name="TypeOfStudent">
                    <option value="Regular">Regular</option>
                    <option value="Transferee">Transferee</option>
                    <option value="New Student">New Student</option>
                </select>
              </div>    

          
          

        </div>

        <div class="modal-footer">
          <button type="submit" name="addUser" class="btn btn-primary">Add User</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Add Modal --> 


<!-- Update Modal -->
<div id="editBtnUser" class="modal fade" role="">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <form action="" method="post">
      <div class="modal-header">
        <h4 class="modal-title">Update User</h4>
      </div>     
      <div class="modal-body">
        
        <input id="update_user_id" name="update_user_id" type="hidden">



        <div class="form-group">
                      <label for="usr">First Name:</label>
                        <input type="text" name="Fname" id="Fname_user" class="form-control" required>
                      </div>
                      <div class="form-group">
                        <label for="usr">Last Name:</label>
                        <input type="text" name="Lname" id="Lname_user" class="form-control" required>
                      </div>
                      <div class="form-group">
                        <label for="usr">Middle Name:</label>
                        <input type="text" name="MName" id="MName_user" class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Suffix:</label>
                        <input type="text" name="Suffix" id="Suffix_user" class="form-control" required >
                      </div>
                      <div class="form-group">
                        <label for="usr">Gender:</label>
                        <input type="text" name="Gender" id="Gender_user" class="form-control" required>
                      </div>    
                      <div class="form-group">
                        <label for="usr">Age:</label>
                        <input type="number" name="Age" id="Age_user" class="form-control" required >
                      </div>
                      <div class="form-group">
                        <label for="usr">Date Of Birth:</label>
                        <input type="date" name="DateOfBirth" id="DateOfBirth_user" class="form-control" required>
                      </div>    
                      <div class="form-group">
                        <label for="usr">Address:</label>
                        <input type="text" name="Address" id="Address_user" class="form-control" required >
                      </div>
                      <div class="form-group">
                        <label for="usr">Parents Or Guardian:</label>
                        <input type="text" name="ParentsOrGuardian" id="ParentsOrGuardian_user" class="form-control" required>
                      </div>    
                      <div class="form-group">
                        <label for="usr">Contact Number:</label>
                        <input type="number" name="ContactNum" id="ContactNum_user" class="form-control" required >
                      </div>
                      <div class="form-group">
                        <label for="usr">Email Address:</label>
                        <input type="email" name="EmailAddress" id="EmailAddress_user" class="form-control" required>
                      </div>    
                      <div class="form-group">
                        <label for="usr">Type of Student:</label>
                        <select class="form-control" name="TypeOfStudent" id="TypeOfStudent_user">
                            <option value="Regular">Regular</option>
                            <option value="Transferee">Transferee</option>
                            <option value="New Student">New Student</option>
                        </select>
                      </div>    



        <div class="modal-footer">
          <button type="submit" name="updateData" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
        </div>
      </form>
    </div>
  </div>
</div>     
<!-- End of Update Modal -->







<!-- Delete Modal -->
<div id="deleteUser" class="modal fade fontStyle" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete User</h4>
        </div>
      <form action="" method="post">
        <div class="modal-body">
          <input id="delete_ids" name="delete_ids" type="hidden">
          <p>Are you sure you want to delete this User?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="delete" class="btn btn-danger">Delete</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>  
  </div>
</div>
<!-- ADD QUERY [Add New Student] -->  
<?php 
  if(isset($_POST["addUser"]))
             {
                $Fname = mysqli_real_escape_string($conn, $_POST["Fname"]);
                $Lname = mysqli_real_escape_string($conn, $_POST["Lname"]);
                $MName = mysqli_real_escape_string($conn, $_POST["MName"]);
                $Suffix = mysqli_real_escape_string($conn, $_POST["Suffix"]);  
                $Gender = mysqli_real_escape_string($conn, $_POST["Gender"]);
                $Age = mysqli_real_escape_string($conn, $_POST["Age"]);
                $DateOfBirth = mysqli_real_escape_string($conn, $_POST["DateOfBirth"]);
                $Address = mysqli_real_escape_string($conn, $_POST["Address"]);
                $ParentsOrGuardian = mysqli_real_escape_string($conn, $_POST["ParentsOrGuardian"]);  
                $ContactNum = mysqli_real_escape_string($conn, $_POST["ContactNum"]);
                $EmailAddress = mysqli_real_escape_string($conn, $_POST["EmailAddress"]);
                $TypeOfStudent = mysqli_real_escape_string($conn, $_POST["TypeOfStudent"]);

                $query_show = mysqli_query($conn, "SELECT * FROM student");
                
                $query = mysqli_query($conn, "SELECT * FROM student WHERE Fname='$Fname' AND Lname='$Lname'");
                 if(mysqli_num_rows($query) > 0) 
                 {
                      $_SESSION['danger'] = 'The student name already exists'; // Set the success message in the session
                      echo '<script> window.location="admin_manage_users.php";</script>';       
                 }
                 else 
                 {
                      //else, i-eexecute nya yung insert query
                      $query_insert = mysqli_query($conn, "INSERT INTO student 
                          VALUES('', '$Fname', '$Lname', '$MName', 
                          '$Suffix', '$Gender', '$Age', '$DateOfBirth', 
                          '$Address', '$ParentsOrGuardian', 
                          '$ContactNum', '$EmailAddress', '$TypeOfStudent')");
                        if($query_insert)
                        {            
                          $_SESSION['success'] = 'Registration Completed!'; // Set the success message in the session
                           echo '<script> window.location="admin_manage_users.php";</script>';                        
                        }
                    
                    
                  }
              }

             if(isset($_POST['deleteData'])){    
                $ID = $_POST['delete_id'];
                $query = mysqli_query($conn, "DELETE FROM student WHERE ID='$ID'");
                if($query) {
                  $_SESSION['success'] = 'Data Deleted'; // Set the success message in the session
                  echo '<script> window.location="admin_manage_users.php";</script>';              
                 
                }
             }
?>  

<!-- End of Delete Modal -->

            </div>
        </div>
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>



<script>
    $(document).ready(function(){
        $('.deleteAdmin').on('click', function(){
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_id').val(data[0]);          
        });
    });




 $(document).ready(function(){
        $('.deleteUser').on('click', function(){
            
         //   $('#deleteUser').modal('show');

       //     $('#deleteUser').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
      //          console.log(data);
            }).get();
            $('#delete_ids').val(data[0]);          
        });
    });



$(document).ready(function(){
    $('.editBtnAdmin').on('click', function(){      
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();
            $('#update_admin_id').val(data[0]);
            $('#FatherFullname').val(data[1]);
            $('#FatherOccupation').val(data[2]);
            $('#FathersContactNumber').val(data[3]);
            $('#MotherFullname').val(data[4]);     
            $('#MotherOccupation').val(data[5]);
            $('#MotherContactNumber').val(data[6]);
            $('#GuardianFullname').val(data[7]);
            $('#RelationshipToStudent').val(data[8]);  
            $('#ContactNum').val(data[9]);


    });
 });




$(document).ready(function(){
    $('.editBtnUser').on('click', function(){      
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function(){
                return $(this).text();
          //      console.log(data);
            }).get();
            $('#update_user_id').val(data[0]);
            $('#Fname_user').val(data[1]);
            $('#Lname_user').val(data[2]);
            $('#MName_user').val(data[3]);
            $('#Suffix_user').val(data[4]);     
            $('#Gender_user').val(data[5]);
            $('#Age_user').val(data[6]);
            $('#DateOfBirth_user').val(data[7]);
            $('#Address_user').val(data[8]);  
            $('#ParentsOrGuardian_user').val(data[9]);
            $('#ContactNum_user').val(data[10]);
            $('#EmailAddress_user').val(data[11]);    
            $('#TypeOfStudent_user').val(data[11]); 

      });
 });



$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});



 var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };


$('input[type="file"]'). change(function(e){
    fileName = e. target. files[0]. name;
    $('#imgLabel').text(fileName);
    $('#imgPreview').attr('src','images/'+fileName);
});



function searchBar() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("searchUser");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableUser");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}




var $td = $('table td').eq(5),
    text = $td.text().replace(/\*/g, '%');

$td.text(text);


</script>


<script>
   // Get all the alerts with the "auto-close" class
  var alerts = document.querySelectorAll('.alert');

  // Loop through the alerts and set a timeout function to remove them after 4 seconds
  alerts.forEach(function(alert) {
    setTimeout(function() {
      alert.remove();
    }, 4000);
  });
</script>










